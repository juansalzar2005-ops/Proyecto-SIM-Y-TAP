package simulador;

import java.util.Random;

public class Ciudadano extends Thread {
    public static final int SANO = 0;
    public static final int ASINTOMATICO = 1;
    public static final int SINTOMATICO = 2;
    public static final int GRAVE = 3;
    public static final int RECUPERADO = 4;
    public static final int FALLECIDO = 5;

    private int id;
    private volatile int x, y; 
    private volatile int estado;
    private int dx, dy;
    private String coloniaOriginal;
    
    private int tiempoInfeccion = 0;
    private int tiempoParaSintomas;
    private int tiempoParaDesenlace; 

    private PanelSimulacion panel;
    private static final Random rand = new Random();
    
    public static volatile boolean enPausa = false;
    public static volatile int multiplicadorVelocidad = 1; 

    public Ciudadano(int id, int x, int y, int estado, String colonia, PanelSimulacion panel) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.estado = estado;
        this.coloniaOriginal = colonia;
        this.panel = panel;
        
                this.tiempoParaSintomas = rand.nextInt(200) + 130;  
       
        this.tiempoParaDesenlace = rand.nextInt(460) + 460; 
        
        this.dx = (rand.nextBoolean() ? 1 : -1) * (rand.nextInt(2) + 1);
        this.dy = (rand.nextBoolean() ? 1 : -1) * (rand.nextInt(2) + 1);
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            if (enPausa) {
                try { Thread.sleep(100); } catch (InterruptedException e) { break; }
                continue; 
            }

            if (estado != FALLECIDO) {
                mover();
                verificarPatologia();
                if (panel != null) {
                    panel.comprobarContagios(this);
                }
            } else {
                break; 
            }
            
            try {
                int delayBase = 30 / multiplicadorVelocidad;
                Thread.sleep(Math.max(2, delayBase)); 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void mover() {
        x += (dx * multiplicadorVelocidad);
        y += (dy * multiplicadorVelocidad);

        if (panel != null) {
           
            if (x <= 0 || x >= 580) dx *= -1;
            if (y <= 0 || y >= panel.getHeight() - 10) dy *= -1;
        }
    }

    private void verificarPatologia() {
        if (estado == ASINTOMATICO || estado == SINTOMATICO || estado == GRAVE) {
            tiempoInfeccion += multiplicadorVelocidad;

            if (estado == ASINTOMATICO && tiempoInfeccion >= tiempoParaSintomas) {
                if (rand.nextDouble() < 0.90) {
                    estado = SINTOMATICO;
                    if (rand.nextDouble() < 0.45) {
                        estado = GRAVE;
                    }
                }
            }

            if (tiempoInfeccion >= tiempoParaDesenlace) {
                if (estado == GRAVE) {
                    if (rand.nextDouble() < 0.65) { 
                        estado = FALLECIDO;
                        panel.registrarMuerte(tiempoInfeccion);
                    } else {
                        estado = RECUPERADO;
                        panel.registrarRecuperacion(tiempoInfeccion);
                    }
                } else if (estado == SINTOMATICO) {
                    if (rand.nextDouble() < 0.15) {
                        estado = FALLECIDO;
                        panel.registrarMuerte(tiempoInfeccion);
                    } else {
                        estado = RECUPERADO;
                        panel.registrarRecuperacion(tiempoInfeccion);
                    }
                } else {
                    estado = RECUPERADO;
                    panel.registrarRecuperacion(tiempoInfeccion);
                }
                
                if (estado == SINTOMATICO || estado == GRAVE || estado == FALLECIDO) {
                    panel.registrarSintomas(tiempoParaSintomas);
                }
            }
        }
    }

    public int getXPos() { return x; }
    public int getYPos() { return y; }
    public int getEstado() { return estado; }
    public String getColonia() { return coloniaOriginal; }
    
    public void infectar() {
        if (this.estado == SANO) {
            this.estado = ASINTOMATICO; 
            this.tiempoInfeccion = 0;
        }
    }
}
