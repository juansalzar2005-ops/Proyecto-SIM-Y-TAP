package simulador;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class PanelSimulacion extends JPanel {
    private List<Ciudadano> poblacion;
    private final int RADIO_CONTAGIO = 9; 
    private final double PROBABILIDAD_COVID = 0.40; 

    private volatile int totalSintomasTiempo = 0, cuentaSintomas = 0;
    private volatile int totalRecuperadosTiempo = 0, cuentaRecuperados = 0;
    private volatile int totalFallecidosTiempo = 0, cuentaFallecidos = 0;

    public PanelSimulacion() {
        this.poblacion = new CopyOnWriteArrayList<>();
        this.setBackground(new Color(12, 16, 22)); 
    }

    public void setPoblacion(List<Ciudadano> poblacion) {
        this.poblacion = new CopyOnWriteArrayList<>(poblacion);
    }

    public void registrarSintomas(int ciclos) { totalSintomasTiempo += ciclos; cuentaSintomas++; }
    public void registrarRecuperacion(int ciclos) { totalRecuperadosTiempo += ciclos; cuentaRecuperados++; }
    public void registrarMuerte(int ciclos) { totalFallecidosTiempo += ciclos; cuentaFallecidos++; }

    public void comprobarContagios(Ciudadano sujetoA) {
        if (sujetoA.getEstado() == Ciudadano.SANO || sujetoA.getEstado() == Ciudadano.RECUPERADO || sujetoA.getEstado() == Ciudadano.FALLECIDO) return;

        for (Ciudadano sujetoB : poblacion) {
            if (sujetoB.getEstado() == Ciudadano.SANO) {
                double distancia = Math.sqrt(Math.pow(sujetoA.getXPos() - sujetoB.getXPos(), 2) +
                                             Math.pow(sujetoA.getYPos() - sujetoB.getYPos(), 2));
                
                if (distancia <= RADIO_CONTAGIO) {
                    if (Math.random() < PROBABILIDAD_COVID) {
                        sujetoB.infectar();
                    }
                }
            }
        }
    }

    private String convertirDiasYSemanas(double promedioCiclos) {
        if (promedioCiclos == 0) return "0 días (0 semanas)";
        double dias = promedioCiclos / 33.0;
        double semanas = dias / 7.0;
        return String.format("%.1f días (Aprox. %.1f semanas)", dias, semanas);
    }

    public String getPromSintomasFormateado() { return convertirDiasYSemanas(cuentaSintomas == 0 ? 0 : (double) totalSintomasTiempo / cuentaSintomas); }
    public String getPromRecuperadosFormateado() { return convertirDiasYSemanas(cuentaRecuperados == 0 ? 0 : (double) totalRecuperadosTiempo / cuentaRecuperados); }
    public String getPromFallecidosFormateado() { return convertirDiasYSemanas(cuentaFallecidos == 0 ? 0 : (double) totalFallecidosTiempo / cuentaFallecidos); }

    public int getCuentaSintomas() { return cuentaSintomas; }
    public int getCuentaRecuperados() { return cuentaRecuperados; }
    public int getCuentaFallecidos() { return cuentaFallecidos; }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        
        g2d.setStroke(new BasicStroke(3));
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        
        int anchoC = 140;
        int altoC = 260;
        Color colorBorde = new Color(55, 75, 95); 
        Color colorFondoCuadrante = new Color(30, 45, 60, 40); 

        
        g2d.setColor(colorFondoCuadrante); g2d.fillRect(5, 5, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(5, 5, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("COL. TAJÍN", 35, 130);

        g2d.setColor(colorFondoCuadrante); g2d.fillRect(150, 5, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(150, 5, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("COL. CAZONES", 165, 130);

        g2d.setColor(colorFondoCuadrante); g2d.fillRect(290, 5, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(290, 5, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("27 DE SEPT.", 315, 130);

        g2d.setColor(colorFondoCuadrante); g2d.fillRect(430, 5, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(430, 5, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("COL. ANÁHUAC", 445, 130);

        
        g2d.setColor(colorFondoCuadrante); g2d.fillRect(5, 270, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(5, 270, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("ÁVILA CAMACHO", 20, 400);

        g2d.setColor(colorFondoCuadrante); g2d.fillRect(150, 270, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(150, 270, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("COL. OBRERA", 170, 400);

        g2d.setColor(colorFondoCuadrante); g2d.fillRect(290, 270, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(290, 270, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("COL. PETROMEX", 305, 400);

        g2d.setColor(colorFondoCuadrante); g2d.fillRect(430, 270, anchoC, altoC);
        g2d.setColor(colorBorde); g2d.drawRect(430, 270, anchoC, altoC);
        g2d.setColor(new Color(255, 255, 255, 90)); g2d.drawString("COL. MORELOS", 450, 400);


      
        int san = 0, enfermos = 0, rec = 0, fal = 0;

        for (Ciudadano c : poblacion) {
            switch (c.getEstado()) {
                case Ciudadano.SANO -> { g2d.setColor(Color.GREEN); san++; }
                case Ciudadano.ASINTOMATICO -> { g2d.setColor(Color.YELLOW); enfermos++; }
                case Ciudadano.SINTOMATICO -> { g2d.setColor(Color.ORANGE); enfermos++; }
                case Ciudadano.GRAVE -> { g2d.setColor(Color.RED); enfermos++; }
                case Ciudadano.RECUPERADO -> { g2d.setColor(Color.CYAN); rec++; }
                case Ciudadano.FALLECIDO -> { g2d.setColor(Color.DARK_GRAY); fal++; }
            }
            if (c.getEstado() != Ciudadano.FALLECIDO) {
                g2d.fillOval(c.getXPos(), c.getYPos(), 6, 6);
            }
        }

      
        int xGrafica = 585;
        g2d.setColor(new Color(22, 28, 35));
        g2d.fillRect(xGrafica, 5, 195, 525);
        g2d.setColor(new Color(60, 75, 90));
        g2d.drawRect(xGrafica, 5, 195, 525);

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 11));
        g2d.drawString("ESTADÍSTICAS EN VIVO", xGrafica + 20, 30);
        g2d.setFont(new Font("Arial", Font.PLAIN, 10));

        int maxPoblacion = poblacion.size() > 0 ? poblacion.size() : 1;
        int anchoSanos = (san * 150) / maxPoblacion;
        int anchoEnfermos = (enfermos * 150) / maxPoblacion;
        int anchoRecuperados = (rec * 150) / maxPoblacion;
        int anchoFallecidos = (fal * 150) / maxPoblacion;

        g2d.setColor(Color.WHITE); g2d.drawString("Sanos (" + san + ")", xGrafica + 15, 75);
        g2d.setColor(Color.GREEN); g2d.fillRect(xGrafica + 15, 85, anchoSanos, 20);

        g2d.setColor(Color.WHITE); g2d.drawString("Infectados Activos (" + enfermos + ")", xGrafica + 15, 140);
        g2d.setColor(Color.RED); g2d.fillRect(xGrafica + 15, 150, anchoEnfermos, 20);

        g2d.setColor(Color.WHITE); g2d.drawString("Recuperados (" + rec + ")", xGrafica + 15, 205);
        g2d.setColor(Color.CYAN); g2d.fillRect(xGrafica + 15, 215, anchoRecuperados, 20);

        g2d.setColor(Color.WHITE); g2d.drawString("Fallecidos (" + fal + ")", xGrafica + 15, 270);
        g2d.setColor(Color.DARK_GRAY); g2d.fillRect(xGrafica + 15, 280, anchoFallecidos, 20);
    }
}
