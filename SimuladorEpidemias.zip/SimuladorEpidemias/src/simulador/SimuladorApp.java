package simulador;

import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SimuladorApp extends JFrame {
    private final int ANCHO = 800;
    private final int ALTO = 600;
    private final int TOTAL_POBLACION = 300; 

    private PanelSimulacion panelSimulacion;
    private List<Ciudadano> poblacion;

    public SimuladorApp() {
        setTitle("Simulacion de Propagacion del COVID-19 en las colonias de Poza Rica, Ver.");
        setSize(ANCHO, ALTO);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        panelSimulacion = new PanelSimulacion();
        add(panelSimulacion, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel();
        panelInferior.setBackground(new Color(25, 28, 34));

        JButton btnPausa = new JButton("⏸️ Pausa");
        JButton btnPDF = new JButton("📄 Exportar PDF Oficial");
        
        JLabel lblVelocidad = new JLabel(" Acelerador: ");
        lblVelocidad.setForeground(Color.WHITE);
        String[] velocidades = {"1x (Normal)", "2x (Rápido)", "4x (Super)", "8x (Luz)"};
        JComboBox<String> comboVelocidad = new JComboBox<>(velocidades);

        comboVelocidad.addActionListener(e -> {
            int index = comboVelocidad.getSelectedIndex();
            if (index == 0) Ciudadano.multiplicadorVelocidad = 1;
            else if (index == 1) Ciudadano.multiplicadorVelocidad = 2;
            else if (index == 2) Ciudadano.multiplicadorVelocidad = 4;
            else if (index == 3) Ciudadano.multiplicadorVelocidad = 8;
        });

        btnPausa.addActionListener(e -> {
            Ciudadano.enPausa = !Ciudadano.enPausa;
            btnPausa.setText(Ciudadano.enPausa ? "▶️ Reanudar" : "⏸️ Pausa");
        });

        btnPDF.addActionListener(e -> {
            Ciudadano.enPausa = true; 
            btnPausa.setText("▶️ Reanudar");
            exportarReporteAPDF();
        });

        panelInferior.add(btnPausa);
        panelInferior.add(lblVelocidad);
        panelInferior.add(comboVelocidad);
        panelInferior.add(btnPDF);
        add(panelInferior, BorderLayout.SOUTH);

        inicializarSimulacion();

        Timer timerRepaint = new Timer(16, e -> panelSimulacion.repaint());
        timerRepaint.start();
    }

    private void exportarReporteAPDF() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Reporte_Epidemiologico_Poza_Rica");

        job.setPrintable((graphics, pageFormat, pageIndex) -> {
            if (pageIndex > 0) return Printable.NO_SUCH_PAGE;

            Graphics2D g2 = (Graphics2D) graphics;
            g2.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

            g2.setColor(Color.DARK_GRAY);
            g2.setFont(new Font("Courier New", Font.BOLD, 16));
            g2.drawString("GOBIERNO DEL ESTADO DE VERACRUZ", 50, 50);
            g2.setFont(new Font("Courier New", Font.PLAIN, 11));
            g2.drawString("SECRETARÍA DE SALUD - JURISDICCIÓN SANITARIA POZA RICA", 50, 70);
            g2.drawString("-------------------------------------------------------", 50, 85);
            
            g2.setFont(new Font("Courier New", Font.BOLD, 13));
            g2.drawString("REPORTE EPIDEMIOLÓGICO: ESTIMACIONES CLÍNICAS (COVID-19)", 50, 110);
            g2.drawString("-------------------------------------------------------", 50, 125);

           
            g2.setFont(new Font("Courier New", Font.PLAIN, 12));
            g2.drawString("• Tiempo Promedio en Presentar Síntomas: ", 50, 150);
            g2.setFont(new Font("Courier New", Font.BOLD, 12));
            g2.drawString(panelSimulacion.getPromSintomasFormateado(), 80, 165);
            
            g2.setFont(new Font("Courier New", Font.PLAIN, 12));
            g2.drawString("• Tiempo Promedio en Lograr Recuperación: ", 50, 195);
            g2.setFont(new Font("Courier New", Font.BOLD, 12));
            g2.drawString(panelSimulacion.getPromRecuperadosFormateado(), 80, 210);
            
            g2.setFont(new Font("Courier New", Font.PLAIN, 12));
            g2.drawString("• Tiempo Promedio registrado de Decesos:  ", 50, 240);
            g2.setFont(new Font("Courier New", Font.BOLD, 12));
            g2.drawString(panelSimulacion.getPromFallecidosFormateado(), 80, 255);
            
            g2.setFont(new Font("Courier New", Font.PLAIN, 11));
            g2.drawString("-------------------------------------------------------", 50, 280);
            g2.drawString("• Casos Totales que manifestaron Síntomas: " + panelSimulacion.getCuentaSintomas(), 50, 300);
            g2.drawString("• Altas Médicas Emitidas (Recuperados):    " + panelSimulacion.getCuentaRecuperados(), 50, 320);
            g2.drawString("• Defunciones Confirmadas en el Municipio: " + panelSimulacion.getCuentaFallecidos(), 50, 340);
            g2.drawString("-------------------------------------------------------", 50, 365);
            
            g2.setFont(new Font("Courier New", Font.ITALIC, 9));
            g2.drawString("Documento oficial en base a la escala de simulación: 1 seg = 1 día.", 50, 390);

            return Printable.PAGE_EXISTS;
        });

       
        if (job.printDialog()) {
            try {
                job.print();
                JOptionPane.showMessageDialog(this, "¡Reporte en PDF generado con éxito!");
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar el documento: " + ex.getMessage());
            }
        }
    }

    private void inicializarSimulacion() {
        poblacion = new ArrayList<>();
        Random rand = new Random();
        String[] colonias = {"Tajín", "Cazones", "27 de Septiembre", "Anáhuac", "Ávila Camacho", "Obrera", "Petromex", "Morelos"};

        for (int i = 0; i < TOTAL_POBLACION - 1; i++) {
            String col = colonias[i % 8];
            int x = 0, y = 0;
            
            
            switch (col) {
                case "Tajín" -> { x = rand.nextInt(120) + 15; y = rand.nextInt(210) + 15; }
                case "Cazones" -> { x = rand.nextInt(120) + 150; y = rand.nextInt(210) + 15; }
                case "27 de Septiembre" -> { x = rand.nextInt(120) + 290; y = rand.nextInt(210) + 15; }
                case "Anáhuac" -> { x = rand.nextInt(120) + 430; y = rand.nextInt(210) + 15; }
                case "Ávila Camacho" -> { x = rand.nextInt(120) + 15; y = rand.nextInt(210) + 280; }
                case "Obrera" -> { x = rand.nextInt(120) + 150; y = rand.nextInt(210) + 280; }
                case "Petromex" -> { x = rand.nextInt(120) + 290; y = rand.nextInt(210) + 280; }
                case "Morelos" -> { x = rand.nextInt(120) + 430; y = rand.nextInt(210) + 280; }
            }
            
            Ciudadano c = new Ciudadano(i, x, y, Ciudadano.SANO, col, panelSimulacion);
            poblacion.add(c);
        }

        Ciudadano pacienteCero = new Ciudadano(TOTAL_POBLACION - 1, 200, 300, Ciudadano.ASINTOMATICO, "Obrera", panelSimulacion);
        poblacion.add(pacienteCero);

        panelSimulacion.setPoblacion(poblacion);

        for (Ciudadano c : poblacion) {
            c.start();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SimuladorApp().setVisible(true);
        });
    }
}
