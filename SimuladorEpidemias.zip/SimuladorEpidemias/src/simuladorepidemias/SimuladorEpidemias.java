
package simuladorepidemias;


public class SimuladorEpidemias {

  
    public static void main(String[] args) {
     
    }
    
}
